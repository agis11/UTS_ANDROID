package com.example.latihanuts

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btn_cal.setOnClickListener {
            val intent = Intent(this, CalActivity::class.java)
            startActivity(intent)
        }


        btn_about.setOnClickListener {
            val namaku = "Agis & Iqbal"
            val email = "iqbal02@gmail.com"
            val phone = "0856051904"

            val about = Intent(this, AboutActivity::class.java)
            about.putExtra("Namaku", namaku)
            about.putExtra("Email", email)
            about.putExtra("Phone", phone)
            startActivity(about)
        }

        btn_form.setOnClickListener {
            val beritaku = "pada tahun 2020 telah terjadi penyebaran virus covid 19,dan masyarakat indonesia mengalami krisis ekonomi "

            val berita = Intent(this, Berita2Activity::class.java)
            berita.putExtra("Berita", beritaku)
            startActivity(berita)
        }
    }
}
